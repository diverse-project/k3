/**
 */
package kmLogo.ASM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pen Up</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kmLogo.ASM.ASMPackage#getPenUp()
 * @model
 * @generated
 */
public interface PenUp extends Primitive {
} // PenUp
