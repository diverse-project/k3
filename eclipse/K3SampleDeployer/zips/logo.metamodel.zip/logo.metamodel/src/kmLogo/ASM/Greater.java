/**
 */
package kmLogo.ASM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Greater</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kmLogo.ASM.ASMPackage#getGreater()
 * @model
 * @generated
 */
public interface Greater extends BinaryExp {
} // Greater
