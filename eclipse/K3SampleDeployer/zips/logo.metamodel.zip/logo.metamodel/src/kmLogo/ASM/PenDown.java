/**
 */
package kmLogo.ASM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pen Down</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kmLogo.ASM.ASMPackage#getPenDown()
 * @model
 * @generated
 */
public interface PenDown extends Primitive {
} // PenDown
