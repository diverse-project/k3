/**
 */
package kmLogo.ASM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Equals</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kmLogo.ASM.ASMPackage#getEquals()
 * @model
 * @generated
 */
public interface Equals extends BinaryExp {
} // Equals
