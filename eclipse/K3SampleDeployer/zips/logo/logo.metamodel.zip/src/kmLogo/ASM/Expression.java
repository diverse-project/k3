/**
 */
package kmLogo.ASM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see kmLogo.ASM.ASMPackage#getExpression()
 * @model abstract="true"
 * @generated
 */
public interface Expression extends Instruction {
} // Expression
