package fr.inria.triskell.k3.sample.logo;

import fr.inria.triskell.k3.Aspect;
import fr.inria.triskell.k3.sample.logo.BinaryExpAspectBinaryExpAspectProperties;
import fr.inria.triskell.k3.sample.logo.Context;
import fr.inria.triskell.k3.sample.logo.ExpressionAspect;
import kmLogo.ASM.BinaryExp;

@Aspect(className = BinaryExp.class)
@SuppressWarnings("all")
public class BinaryExpAspect extends ExpressionAspect {
  public static int eval(final BinaryExp _self, final Context context) {
    fr.inria.triskell.k3.sample.logo.BinaryExpAspectBinaryExpAspectContext _instance = fr.inria.triskell.k3.sample.logo.BinaryExpAspectBinaryExpAspectContext.getInstance();
    				    java.util.Map<BinaryExp,fr.inria.triskell.k3.sample.logo.BinaryExpAspectBinaryExpAspectProperties> selfProp = _instance.getMap();
    					boolean _containsKey = selfProp.containsKey(_self);
    				    boolean _not = (!_containsKey);
    				    if (_not) {
      						fr.inria.triskell.k3.sample.logo.BinaryExpAspectBinaryExpAspectProperties prop = new fr.inria.triskell.k3.sample.logo.BinaryExpAspectBinaryExpAspectProperties();
    				   selfProp.put(_self, prop);
    			    }
    			     _self_ = selfProp.get(_self);
    			        if (_self instanceof kmLogo.ASM.Plus){
    			     							return fr.inria.triskell.k3.sample.logo.PlusAspect.priveval((kmLogo.ASM.Plus)_self,context);
    			     							} else    if (_self instanceof kmLogo.ASM.Minus){
    			     							return fr.inria.triskell.k3.sample.logo.MinusAspect.priveval((kmLogo.ASM.Minus)_self,context);
    			     							} else    if (_self instanceof kmLogo.ASM.Mult){
    			     							return fr.inria.triskell.k3.sample.logo.MultAspect.priveval((kmLogo.ASM.Mult)_self,context);
    			     							} else    if (_self instanceof kmLogo.ASM.Div){
    			     							return fr.inria.triskell.k3.sample.logo.DivAspect.priveval((kmLogo.ASM.Div)_self,context);
    			     							} else    if (_self instanceof kmLogo.ASM.Equals){
    			     							return fr.inria.triskell.k3.sample.logo.EqualsAspect.priveval((kmLogo.ASM.Equals)_self,context);
    			     							} else    if (_self instanceof kmLogo.ASM.Greater){
    			     							return fr.inria.triskell.k3.sample.logo.GreaterAspect.priveval((kmLogo.ASM.Greater)_self,context);
    			     							} else    if (_self instanceof kmLogo.ASM.Lower){
    			     							return fr.inria.triskell.k3.sample.logo.LowerAspect.priveval((kmLogo.ASM.Lower)_self,context);
    			     							} else    if (_self instanceof kmLogo.ASM.BinaryExp){
    			     							return fr.inria.triskell.k3.sample.logo.BinaryExpAspect.priveval((kmLogo.ASM.BinaryExp)_self,context);
    			     							} else    if (_self instanceof kmLogo.ASM.Expression){
    			     							return fr.inria.triskell.k3.sample.logo.ExpressionAspect.priveval((kmLogo.ASM.Expression)_self,context);
    			     							} else    if (_self instanceof kmLogo.ASM.Instruction){
    			     							return fr.inria.triskell.k3.sample.logo.InstructionAspect.priveval((kmLogo.ASM.Instruction)_self,context);
    			     							} else 
    			      {
    			       										throw new IllegalArgumentException("Unhandled parameter types: " +
    			     							        java.util.Arrays.<Object>asList(_self).toString());
    			     					    } 
    
  }
  
  public static BinaryExpAspectBinaryExpAspectProperties _self_;
  
  protected static int priveval(final BinaryExp _self, final Context context) {
    return 0;
  }
}
