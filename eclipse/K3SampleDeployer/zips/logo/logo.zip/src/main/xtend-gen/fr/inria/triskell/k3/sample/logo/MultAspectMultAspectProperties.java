package fr.inria.triskell.k3.sample.logo;

@SuppressWarnings("all")
public class MultAspectMultAspectProperties {
}
