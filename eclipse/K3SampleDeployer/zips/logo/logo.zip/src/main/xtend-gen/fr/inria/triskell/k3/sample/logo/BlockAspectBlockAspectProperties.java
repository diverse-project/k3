package fr.inria.triskell.k3.sample.logo;

@SuppressWarnings("all")
public class BlockAspectBlockAspectProperties {
  public int res = 0;
}
