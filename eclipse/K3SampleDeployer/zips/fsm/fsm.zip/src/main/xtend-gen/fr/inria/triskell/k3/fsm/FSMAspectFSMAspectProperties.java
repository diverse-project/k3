package fr.inria.triskell.k3.fsm;

import fsm.State;

@SuppressWarnings("all")
public class FSMAspectFSMAspectProperties {
  public State currentState;
}
