package fr.inria.triskell.k3.fsm;

import fr.inria.triskell.k3.fsm.FSMAspectFSMAspectProperties;
import fsm.FSM;
import java.util.Map;

@SuppressWarnings("all")
public class FSMAspectFSMAspectContext {
  public final static FSMAspectFSMAspectContext INSTANCE = new FSMAspectFSMAspectContext();
  
  public static FSMAspectFSMAspectContext getInstance() {
    return INSTANCE;
  }
  
  private Map<FSM,FSMAspectFSMAspectProperties> map = new java.util.HashMap<FSM, fr.inria.triskell.k3.fsm.FSMAspectFSMAspectProperties>();
  
  public Map<FSM,FSMAspectFSMAspectProperties> getMap() {
    return map;
  }
}
