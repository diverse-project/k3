package fr.inria.triskell.k3.fsm;

import com.google.common.base.Objects;
import fr.inria.triskell.k3.Aspect;
import fr.inria.triskell.k3.fsm.Console;
import fr.inria.triskell.k3.fsm.FSMAspectFSMAspectProperties;
import fr.inria.triskell.k3.fsm.NoTransition;
import fr.inria.triskell.k3.fsm.NonDeterminism;
import fr.inria.triskell.k3.fsm.StateAspect;
import fsm.FSM;
import fsm.State;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.InputOutput;

@Aspect(className = FSM.class)
@SuppressWarnings("all")
public class FSMAspect {
  public static void run(final FSM _self) {
    fr.inria.triskell.k3.fsm.FSMAspectFSMAspectContext _instance = fr.inria.triskell.k3.fsm.FSMAspectFSMAspectContext.getInstance();
    				    java.util.Map<FSM,fr.inria.triskell.k3.fsm.FSMAspectFSMAspectProperties> selfProp = _instance.getMap();
    					boolean _containsKey = selfProp.containsKey(_self);
    				    boolean _not = (!_containsKey);
    				    if (_not) {
      						fr.inria.triskell.k3.fsm.FSMAspectFSMAspectProperties prop = new fr.inria.triskell.k3.fsm.FSMAspectFSMAspectProperties();
    				   selfProp.put(_self, prop);
    			    }
    			     _self_ = selfProp.get(_self);
    			      privrun(_self); 
    
  }
  
  public static FSMAspectFSMAspectProperties _self_;
  
  public static State currentState(final FSM _self) {
    fr.inria.triskell.k3.fsm.FSMAspectFSMAspectContext _instance = fr.inria.triskell.k3.fsm.FSMAspectFSMAspectContext.getInstance();
    				    java.util.Map<FSM,fr.inria.triskell.k3.fsm.FSMAspectFSMAspectProperties> selfProp = _instance.getMap();
    					boolean _containsKey = selfProp.containsKey(_self);
    				    boolean _not = (!_containsKey);
    				    if (_not) {
      						fr.inria.triskell.k3.fsm.FSMAspectFSMAspectProperties prop = new fr.inria.triskell.k3.fsm.FSMAspectFSMAspectProperties();
    				   selfProp.put(_self, prop);
    			    }
    			     _self_ = selfProp.get(_self);
    			     return privcurrentState(_self); 
    
  }
  
  public static void currentState(final FSM _self, final State currentState) {
    fr.inria.triskell.k3.fsm.FSMAspectFSMAspectContext _instance = fr.inria.triskell.k3.fsm.FSMAspectFSMAspectContext.getInstance();
    				    java.util.Map<FSM,fr.inria.triskell.k3.fsm.FSMAspectFSMAspectProperties> selfProp = _instance.getMap();
    					boolean _containsKey = selfProp.containsKey(_self);
    				    boolean _not = (!_containsKey);
    				    if (_not) {
      						fr.inria.triskell.k3.fsm.FSMAspectFSMAspectProperties prop = new fr.inria.triskell.k3.fsm.FSMAspectFSMAspectProperties();
    				   selfProp.put(_self, prop);
    			    }
    			     _self_ = selfProp.get(_self);
    			      privcurrentState(_self,currentState); 
    
  }
  
  protected static void privrun(final FSM _self) {
    State _currentState = FSMAspect.currentState(_self);
    boolean _equals = Objects.equal(_currentState, null);
    if (_equals) {
      State _initialState = _self.getInitialState();
      FSMAspect.currentState(_self, _initialState);
    }
    String str = "init";
    boolean _notEquals = (!Objects.equal(str, "quit"));
    boolean _while = _notEquals;
    while (_while) {
      {
        State _currentState_1 = FSMAspect.currentState(_self);
        String _name = _currentState_1.getName();
        String _plus = ("Current state : " + _name);
        InputOutput.<String>println(_plus);
        Console _instance = Console.getInstance();
        String _readLine = _instance.readLine("give me a letter : ");
        str = _readLine;
        boolean _equals_1 = Objects.equal(str, "quit");
        if (_equals_1) {
          InputOutput.<String>println("");
          InputOutput.<String>println("quitting ...");
        } else {
          boolean _equals_2 = Objects.equal(str, "print");
          if (_equals_2) {
            InputOutput.<String>println("");
          } else {
            InputOutput.<String>println(str);
          }
        }
        InputOutput.<String>println("stepping...");
        try {
          State _currentState_2 = FSMAspect.currentState(_self);
          String textRes = StateAspect.step(_currentState_2, str);
          boolean _or = false;
          boolean _equals_3 = Objects.equal(textRes, void.class);
          if (_equals_3) {
            _or = true;
          } else {
            boolean _equals_4 = Objects.equal(textRes, "");
            _or = (_equals_3 || _equals_4);
          }
          if (_or) {
            textRes = "NC";
          }
          String _plus_1 = ("string produced : " + textRes);
          InputOutput.<String>println(_plus_1);
        } catch (final Throwable _t) {
          if (_t instanceof NonDeterminism) {
            final NonDeterminism err = (NonDeterminism)_t;
            String _string = err.toString();
            InputOutput.<String>println(_string);
            str = "quit";
          } else if (_t instanceof NoTransition) {
            final NoTransition err_1 = (NoTransition)_t;
            String _string_1 = err_1.toString();
            InputOutput.<String>println(_string_1);
            str = "quit";
          } else {
            throw Exceptions.sneakyThrow(_t);
          }
        }
      }
      boolean _notEquals_1 = (!Objects.equal(str, "quit"));
      _while = _notEquals_1;
    }
  }
  
  protected static State privcurrentState(final FSM _self) {
     return fr.inria.triskell.k3.fsm.FSMAspect._self_.currentState; 
  }
  
  protected static void privcurrentState(final FSM _self, final State currentState) {
    fr.inria.triskell.k3.fsm.FSMAspect._self_.currentState = currentState; 
  }
}
