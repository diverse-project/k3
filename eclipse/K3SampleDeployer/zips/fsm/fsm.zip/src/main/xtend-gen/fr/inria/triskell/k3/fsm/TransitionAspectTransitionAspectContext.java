package fr.inria.triskell.k3.fsm;

import fr.inria.triskell.k3.fsm.TransitionAspectTransitionAspectProperties;
import fsm.Transition;
import java.util.Map;

@SuppressWarnings("all")
public class TransitionAspectTransitionAspectContext {
  public final static TransitionAspectTransitionAspectContext INSTANCE = new TransitionAspectTransitionAspectContext();
  
  public static TransitionAspectTransitionAspectContext getInstance() {
    return INSTANCE;
  }
  
  private Map<Transition,TransitionAspectTransitionAspectProperties> map = new java.util.HashMap<Transition, fr.inria.triskell.k3.fsm.TransitionAspectTransitionAspectProperties>();
  
  public Map<Transition,TransitionAspectTransitionAspectProperties> getMap() {
    return map;
  }
}
