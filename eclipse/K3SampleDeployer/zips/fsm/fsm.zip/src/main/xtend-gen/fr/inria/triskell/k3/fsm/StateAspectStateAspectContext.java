package fr.inria.triskell.k3.fsm;

import fr.inria.triskell.k3.fsm.StateAspectStateAspectProperties;
import fsm.State;
import java.util.Map;

@SuppressWarnings("all")
public class StateAspectStateAspectContext {
  public final static StateAspectStateAspectContext INSTANCE = new StateAspectStateAspectContext();
  
  public static StateAspectStateAspectContext getInstance() {
    return INSTANCE;
  }
  
  private Map<State,StateAspectStateAspectProperties> map = new java.util.HashMap<State, fr.inria.triskell.k3.fsm.StateAspectStateAspectProperties>();
  
  public Map<State,StateAspectStateAspectProperties> getMap() {
    return map;
  }
}
