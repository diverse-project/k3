package fr.inria.triskell.k3.fsm;

import fr.inria.triskell.k3.fsm.FSMException;

@SuppressWarnings("all")
public class NoInitialStateException extends FSMException {
}
