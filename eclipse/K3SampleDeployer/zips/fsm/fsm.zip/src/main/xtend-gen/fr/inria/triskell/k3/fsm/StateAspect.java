package fr.inria.triskell.k3.fsm;

import fr.inria.triskell.k3.Aspect;
import fr.inria.triskell.k3.fsm.NoTransition;
import fr.inria.triskell.k3.fsm.NonDeterminism;
import fr.inria.triskell.k3.fsm.StateAspectStateAspectProperties;
import fr.inria.triskell.k3.fsm.TransitionAspect;
import fsm.State;
import fsm.Transition;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@Aspect(className = State.class)
@SuppressWarnings("all")
public class StateAspect {
  public static String step(final State _self, final String c) {
    fr.inria.triskell.k3.fsm.StateAspectStateAspectContext _instance = fr.inria.triskell.k3.fsm.StateAspectStateAspectContext.getInstance();
    				    java.util.Map<State,fr.inria.triskell.k3.fsm.StateAspectStateAspectProperties> selfProp = _instance.getMap();
    					boolean _containsKey = selfProp.containsKey(_self);
    				    boolean _not = (!_containsKey);
    				    if (_not) {
      						fr.inria.triskell.k3.fsm.StateAspectStateAspectProperties prop = new fr.inria.triskell.k3.fsm.StateAspectStateAspectProperties();
    				   selfProp.put(_self, prop);
    			    }
    			     _self_ = selfProp.get(_self);
    			     return privstep(_self,c); 
    
  }
  
  public static StateAspectStateAspectProperties _self_;
  
  protected static String privstep(final State _self, final String c) {
    try {
      EList<Transition> _outgoingTransition = _self.getOutgoingTransition();
      final Function1<Transition,Boolean> _function = new Function1<Transition,Boolean>() {
          public Boolean apply(final Transition t) {
            String _input = t.getInput();
            boolean _equals = _input.equals(c);
            return Boolean.valueOf(_equals);
          }
        };
      Iterable<Transition> validTransitions = IterableExtensions.<Transition>filter(_outgoingTransition, _function);
      boolean _isEmpty = IterableExtensions.isEmpty(validTransitions);
      if (_isEmpty) {
        NoTransition _noTransition = new NoTransition();
        throw _noTransition;
      }
      int _size = IterableExtensions.size(validTransitions);
      boolean _greaterThan = (_size > 1);
      if (_greaterThan) {
        NonDeterminism _nonDeterminism = new NonDeterminism();
        throw _nonDeterminism;
      }
      final Iterable<Transition> _converted_validTransitions = (Iterable<Transition>)validTransitions;
      Transition _get = ((Transition[])Conversions.unwrapArray(_converted_validTransitions, Transition.class))[0];
      return TransitionAspect.fire(_get);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
}
