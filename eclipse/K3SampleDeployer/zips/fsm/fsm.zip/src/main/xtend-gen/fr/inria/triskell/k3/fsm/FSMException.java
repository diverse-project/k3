package fr.inria.triskell.k3.fsm;

@SuppressWarnings("all")
public abstract class FSMException extends Exception {
}
