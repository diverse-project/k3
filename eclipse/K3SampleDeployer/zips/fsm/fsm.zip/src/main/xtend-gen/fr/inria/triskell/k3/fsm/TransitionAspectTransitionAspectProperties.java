package fr.inria.triskell.k3.fsm;

@SuppressWarnings("all")
public class TransitionAspectTransitionAspectProperties {
}
