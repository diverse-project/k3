package fr.inria.triskell.k3.fsm;

import fr.inria.triskell.k3.Aspect;
import fr.inria.triskell.k3.fsm.FSMAspect;
import fr.inria.triskell.k3.fsm.TransitionAspectTransitionAspectProperties;
import fsm.FSM;
import fsm.State;
import fsm.Transition;

@Aspect(className = Transition.class)
@SuppressWarnings("all")
public class TransitionAspect {
  public static String fire(final Transition _self) {
    fr.inria.triskell.k3.fsm.TransitionAspectTransitionAspectContext _instance = fr.inria.triskell.k3.fsm.TransitionAspectTransitionAspectContext.getInstance();
    				    java.util.Map<Transition,fr.inria.triskell.k3.fsm.TransitionAspectTransitionAspectProperties> selfProp = _instance.getMap();
    					boolean _containsKey = selfProp.containsKey(_self);
    				    boolean _not = (!_containsKey);
    				    if (_not) {
      						fr.inria.triskell.k3.fsm.TransitionAspectTransitionAspectProperties prop = new fr.inria.triskell.k3.fsm.TransitionAspectTransitionAspectProperties();
    				   selfProp.put(_self, prop);
    			    }
    			     _self_ = selfProp.get(_self);
    			     return privfire(_self); 
    
  }
  
  public static TransitionAspectTransitionAspectProperties _self_;
  
  protected static String privfire(final Transition _self) {
    State _source = _self.getSource();
    FSM _owningFSM = _source.getOwningFSM();
    State _target = _self.getTarget();
    FSMAspect.currentState(_owningFSM, _target);
    return _self.getOutput();
  }
}
