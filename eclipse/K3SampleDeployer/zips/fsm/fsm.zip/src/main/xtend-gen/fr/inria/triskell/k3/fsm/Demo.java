package fr.inria.triskell.k3.fsm;

import fr.inria.triskell.k3.fsm.FSMAspect;
import fsm.FSM;
import fsm.FsmPackage;
import java.util.Map;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage.Registry;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.xtext.xbase.lib.InputOutput;

@SuppressWarnings("all")
public class Demo {
  public void run() {
    XMIResourceFactoryImpl _xMIResourceFactoryImpl = new XMIResourceFactoryImpl();
    XMIResourceFactoryImpl fact = _xMIResourceFactoryImpl;
    boolean _containsKey = Registry.INSTANCE.containsKey(FsmPackage.eNS_URI);
    boolean _not = (!_containsKey);
    if (_not) {
      Registry.INSTANCE.put(FsmPackage.eNS_URI, FsmPackage.eINSTANCE);
    }
    Map<String,Object> _extensionToFactoryMap = org.eclipse.emf.ecore.resource.Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap();
    _extensionToFactoryMap.put("*", fact);
    ResourceSetImpl _resourceSetImpl = new ResourceSetImpl();
    ResourceSetImpl rs = _resourceSetImpl;
    URI uri = URI.createURI("TrafficLights.fsm");
    Resource res = rs.getResource(uri, true);
    EList<EObject> _contents = res.getContents();
    EObject _get = _contents.get(0);
    FSM fsm = ((FSM) _get);
    FSMAspect.run(fsm);
  }
  
  public static void main(final String[] args) {
    InputOutput.<String>println("Hello K3 based on xtend!");
    Demo _demo = new Demo();
    _demo.run();
  }
}
