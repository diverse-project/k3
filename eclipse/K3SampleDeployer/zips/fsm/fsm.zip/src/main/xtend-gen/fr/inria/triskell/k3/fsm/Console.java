package fr.inria.triskell.k3.fsm;

import com.google.common.base.Objects;
import fr.inria.triskell.k3.Singleton;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.InputOutput;

/**
 * $Id: fsm_Operationnal_Semantics.kmt,v 1.3 2008-08-25 13:04:01 vmahe Exp $
 * Project    : fr.irisa.triskell.samples.fsm
 * File       : fsmmodel.kmt
 * License    : EPL
 * Copyright  : IRISA / INRIA / Universite de Rennes 1
 * -------------------------------------------------------------------
 * Creation date : 03 October. 2005
 * Modified By :
 *        Waqas Ahmed Saeed <wahmedsa@irisa.fr>
 *        Cyril Faucher <cfaucher@irisa.fr>
 * Description :
 *       Finite State Machine Sample with Behaviour implemented in Kermeta
 */
@Singleton
@SuppressWarnings("all")
public final class Console {
  private Console() {
    // singleton
  }
  
  public String readLine(final String format, final Object... args) {
    java.io.Console _console = System.console();
    boolean _notEquals = (!Objects.equal(_console, null));
    if (_notEquals) {
      java.io.Console _console_1 = System.console();
      return _console_1.readLine(format, args);
    }
    String _format = String.format(format, args);
    InputOutput.<String>println(_format);
    InputStreamReader _inputStreamReader = new InputStreamReader(System.in);
    BufferedReader _bufferedReader = new BufferedReader(_inputStreamReader);
    BufferedReader reader = _bufferedReader;
    try {
      return reader.readLine();
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  private final static Console INSTANCE = new Console();
  
  public static Console getInstance() {
    return INSTANCE;
  }
}
