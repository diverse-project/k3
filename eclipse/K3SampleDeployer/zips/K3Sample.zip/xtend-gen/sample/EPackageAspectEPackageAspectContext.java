package sample;

import java.util.Map;
import org.eclipse.emf.ecore.EPackage;
import sample.EPackageAspectEPackageAspectProperties;

@SuppressWarnings("all")
public class EPackageAspectEPackageAspectContext {
  public final static EPackageAspectEPackageAspectContext INSTANCE = new EPackageAspectEPackageAspectContext();
  
  public static EPackageAspectEPackageAspectContext getInstance() {
    return INSTANCE;
  }
  
  private Map<EPackage,EPackageAspectEPackageAspectProperties> map = new java.util.HashMap<EPackage, sample.EPackageAspectEPackageAspectProperties>();
  
  public Map<EPackage,EPackageAspectEPackageAspectProperties> getMap() {
    return map;
  }
}
