package sample;

import fr.inria.triskell.k3.Aspect;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.xtext.xbase.lib.InputOutput;
import sample.EPackageAspectEPackageAspectProperties;

@Aspect(className = EPackage.class)
@SuppressWarnings("all")
public class EPackageAspect {
  public static void start(final EPackage _self) {
    sample.EPackageAspectEPackageAspectContext _instance = sample.EPackageAspectEPackageAspectContext.getInstance();
    				    java.util.Map<EPackage,sample.EPackageAspectEPackageAspectProperties> selfProp = _instance.getMap();
    					boolean _containsKey = selfProp.containsKey(_self);
    				    boolean _not = (!_containsKey);
    				    if (_not) {
      						sample.EPackageAspectEPackageAspectProperties prop = new sample.EPackageAspectEPackageAspectProperties();
    				   selfProp.put(_self, prop);
    			    }
    			     _self_ = selfProp.get(_self);
    			      privstart(_self); 
    
  }
  
  public static void sayHello(final EPackage _self, final String say) {
    sample.EPackageAspectEPackageAspectContext _instance = sample.EPackageAspectEPackageAspectContext.getInstance();
    				    java.util.Map<EPackage,sample.EPackageAspectEPackageAspectProperties> selfProp = _instance.getMap();
    					boolean _containsKey = selfProp.containsKey(_self);
    				    boolean _not = (!_containsKey);
    				    if (_not) {
      						sample.EPackageAspectEPackageAspectProperties prop = new sample.EPackageAspectEPackageAspectProperties();
    				   selfProp.put(_self, prop);
    			    }
    			     _self_ = selfProp.get(_self);
    			      privsayHello(_self,say); 
    
  }
  
  public static EPackageAspectEPackageAspectProperties _self_;
  
  public static int i(final EPackage _self) {
    sample.EPackageAspectEPackageAspectContext _instance = sample.EPackageAspectEPackageAspectContext.getInstance();
    				    java.util.Map<EPackage,sample.EPackageAspectEPackageAspectProperties> selfProp = _instance.getMap();
    					boolean _containsKey = selfProp.containsKey(_self);
    				    boolean _not = (!_containsKey);
    				    if (_not) {
      						sample.EPackageAspectEPackageAspectProperties prop = new sample.EPackageAspectEPackageAspectProperties();
    				   selfProp.put(_self, prop);
    			    }
    			     _self_ = selfProp.get(_self);
    			     return privi(_self); 
    
  }
  
  public static void i(final EPackage _self, final int i) {
    sample.EPackageAspectEPackageAspectContext _instance = sample.EPackageAspectEPackageAspectContext.getInstance();
    				    java.util.Map<EPackage,sample.EPackageAspectEPackageAspectProperties> selfProp = _instance.getMap();
    					boolean _containsKey = selfProp.containsKey(_self);
    				    boolean _not = (!_containsKey);
    				    if (_not) {
      						sample.EPackageAspectEPackageAspectProperties prop = new sample.EPackageAspectEPackageAspectProperties();
    				   selfProp.put(_self, prop);
    			    }
    			     _self_ = selfProp.get(_self);
    			      privi(_self,i); 
    
  }
  
  public static int j(final EPackage _self) {
    sample.EPackageAspectEPackageAspectContext _instance = sample.EPackageAspectEPackageAspectContext.getInstance();
    				    java.util.Map<EPackage,sample.EPackageAspectEPackageAspectProperties> selfProp = _instance.getMap();
    					boolean _containsKey = selfProp.containsKey(_self);
    				    boolean _not = (!_containsKey);
    				    if (_not) {
      						sample.EPackageAspectEPackageAspectProperties prop = new sample.EPackageAspectEPackageAspectProperties();
    				   selfProp.put(_self, prop);
    			    }
    			     _self_ = selfProp.get(_self);
    			     return privj(_self); 
    
  }
  
  public static void j(final EPackage _self, final int j) {
    sample.EPackageAspectEPackageAspectContext _instance = sample.EPackageAspectEPackageAspectContext.getInstance();
    				    java.util.Map<EPackage,sample.EPackageAspectEPackageAspectProperties> selfProp = _instance.getMap();
    					boolean _containsKey = selfProp.containsKey(_self);
    				    boolean _not = (!_containsKey);
    				    if (_not) {
      						sample.EPackageAspectEPackageAspectProperties prop = new sample.EPackageAspectEPackageAspectProperties();
    				   selfProp.put(_self, prop);
    			    }
    			     _self_ = selfProp.get(_self);
    			      privj(_self,j); 
    
  }
  
  protected static void privstart(final EPackage _self) {
    int _i = EPackageAspect.i(_self);
    int _plus = (_i + 1);
    EPackageAspect.i(_self, _plus);
    int _i_1 = EPackageAspect.i(_self);
    InputOutput.<Integer>println(Integer.valueOf(_i_1));
    int _j = EPackageAspect.j(_self);
    int _plus_1 = (_j + 1);
    EPackageAspect.j(_self, _plus_1);
    int _j_1 = EPackageAspect.j(_self);
    InputOutput.<Integer>println(Integer.valueOf(_j_1));
  }
  
  protected static void privsayHello(final EPackage _self, final String say) {
    InputOutput.<String>println(say);
  }
  
  protected static int privi(final EPackage _self) {
     return sample.EPackageAspect._self_.i; 
  }
  
  protected static void privi(final EPackage _self, final int i) {
    sample.EPackageAspect._self_.i = i; 
  }
  
  protected static int privj(final EPackage _self) {
     return sample.EPackageAspect._self_.j; 
  }
  
  protected static void privj(final EPackage _self, final int j) {
    sample.EPackageAspect._self_.j = j; 
  }
}
