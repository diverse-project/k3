package sample;

@SuppressWarnings("all")
public class EPackageAspectEPackageAspectProperties {
  public static int i = 0;
  
  public int j;
}
